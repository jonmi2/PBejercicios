def escribir_vector(V):
    print("[ ", end="")
    for i in range(0,len(V)):
        print(str(V[i]) + " ", end="")        
    print("]", end="")    


def ordenar_impares_y_pares(V):
    i=0;
    j=len(V)-1;
    aux=0;
    while i<j:
        
        if (V[i]%2)!=0:
            i=i+1;    
            
        elif (V[j]%2)==0:
            j=j-1;
    
        elif (V[i]%2)==0 and (V[j]%2)!=0:
            #print("CAMBIO " + str(V[i]) + "y " + str(V[j]))
            aux=V[i];
            V[i]=V[j];
            V[j]=aux;
            i=i+1
            j=j-1
            
               
    return(V)

def principal():
    #Caso 1 
     vector1 = [10, 3, 13, 4, 6, 3, 5, 2, 9, 7, 8, 18, 12, 2]
     
     print("El vector inicial es (10,3,13,4,6,3,5,2,9,7,8,18,12,2):")
     escribir_vector(vector1)

     vector1=ordenar_impares_y_pares(vector1)
     print("El vector final deberia ser (3,13,3,5,9,7,   10,4,6,2,8,18,12,2)")
     print(" SIN IMPORTAR EL ORDEN de los pares entre si, ni de los impares entre si")
     print("y segun vuestro programa es:")
     escribir_vector(vector1)
     print("\n")
    
    #Caso 2 
     vector1 = [2, 4, 6, 2, 4, 5, 9, 7, 11, 19]
     
     print("El vector inicial es (2, 4, 6, 2, 4, 5, 9, 7, 11, 19):")
     escribir_vector(vector1)

     vector1=ordenar_impares_y_pares(vector1)
     print("El vector final deberia ser (19, 11, 7, 9, 5, 4, 2, 6, 4, 2)")
     print(" SIN IMPORTAR EL ORDEN de los pares entre si, ni de los impares entre si")
     print("y segun vuestro programa es:")
     escribir_vector(vector1)
     print("\n")
    
    #Caso 3 
     vector1 = [11, 3, 5, 7, 2, 4, 6, 18]
     
     print("El vector inicial es (11, 3, 5, 7, 2, 4, 6, 18):")
     escribir_vector(vector1)

     vector1=ordenar_impares_y_pares(vector1)
     print("El vector final deberia ser (11, 3, 5, 7, 2, 4, 6, 18)")
     print(" SIN IMPORTAR EL ORDEN de los pares entre si, ni de los impares entre si")
     print("y segun vuestro programa es:")
     escribir_vector(vector1)
     print("\n")
    
    #Caso 4 
     vector1 = [11, 3, 5, 7, 3, 7, 9, 11]
     
     print("El vector inicial es (11, 3, 5, 7, 3, 7, 9, 11):")
     escribir_vector(vector1)

     vector1=ordenar_impares_y_pares(vector1)
     print("El vector final deberia ser (11, 3, 5, 7, 3, 7, 9, 11)")
     print(" SIN IMPORTAR EL ORDEN de los pares entre si, ni de los impares entre si")
     print("y segun vuestro programa es:")
     escribir_vector(vector1)
     print("\n")
    
   #Caso 5 
     vector1 = [2, 4, 8, 10, 4, 6, 2, 12]
     
     print("El vector inicial es (2, 4, 8, 10, 4, 6, 2, 12):")
     escribir_vector(vector1)

     vector1=ordenar_impares_y_pares(vector1)
     print("El vector final deberia ser (2, 4, 8, 10, 4, 6, 2, 12)")
     print(" SIN IMPORTAR EL ORDEN de los pares entre si, ni de los impares entre si")
     print("y segun vuestro programa es:")
     escribir_vector(vector1)
     print("\n")
     
   #Caso 6 
     vector1 = []
     
     print("El vector inicial es ():")
     escribir_vector(vector1)

     vector1=ordenar_impares_y_pares(vector1)
     print("El vector final deberia ser ()")
     print(" SIN IMPORTAR EL ORDEN de los pares entre si, ni de los impares entre si")
     print("y segun vuestro programa es:")
     escribir_vector(vector1)
     print("\n")
        
   #Caso 7 
     vector1 = [2, 4]
     
     print("El vector inicial es (2, 4):")
     escribir_vector(vector1)

     vector1=ordenar_impares_y_pares(vector1)
     print("El vector final deberia ser (2, 4)")
     print(" SIN IMPORTAR EL ORDEN de los pares entre si, ni de los impares entre si")
     print("y segun vuestro programa es:")
     escribir_vector(vector1)
     print("\n")
        
   #Caso 8 
     vector1 = [3, 7]
     
     print("El vector inicial es (3, 7):")
     escribir_vector(vector1)

     vector1=ordenar_impares_y_pares(vector1)
     print("El vector final deberia ser (3, 7)")
     print(" SIN IMPORTAR EL ORDEN de los pares entre si, ni de los impares entre si")
     print("y segun vuestro programa es:")
     escribir_vector(vector1)
     print("\n")
     
   #Caso 9 
     vector1 = [3, 2]
     
     print("El vector inicial es (3, 2):")
     escribir_vector(vector1)

     vector1=ordenar_impares_y_pares(vector1)
     print("El vector final deberia ser (3, 2)")
     print(" SIN IMPORTAR EL ORDEN de los pares entre si, ni de los impares entre si")
     print("y segun vuestro programa es:")
     escribir_vector(vector1)
     print("\n")
    
   #Caso 10 
     vector1 = [2, 3]
     
     print("El vector inicial es (2, 3):")
     escribir_vector(vector1)

     vector1=ordenar_impares_y_pares(vector1)
     print("El vector final deberia ser (3, 2)")
     print(" SIN IMPORTAR EL ORDEN de los pares entre si, ni de los impares entre si")
     print("y segun vuestro programa es:")
     escribir_vector(vector1)
     print("\n")
        
   #Caso 11 
     vector1 = [2, 7, 6, 1]
     
     print("El vector inicial es (2, 7, 6, 1):")
     escribir_vector(vector1)

     vector1=ordenar_impares_y_pares(vector1)
     print("El vector final deberia ser (1, 7, 6, 2)")
     print(" SIN IMPORTAR EL ORDEN de los pares entre si, ni de los impares entre si")
     print("y segun vuestro programa es:")
     escribir_vector(vector1)
     print("\n")
principal()
