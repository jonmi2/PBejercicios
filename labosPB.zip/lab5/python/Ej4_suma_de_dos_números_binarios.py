def suma_binaria(binario1,binario2):
    suma=0;
    llevada=0;
    peso=0;
    
    while int(binario1!=0) or int(binario2!=0): 
        resto1= binario1 % 10;
        resto2= binario2 % 10;
        
        digito = resto1 + resto2;
        suma = suma + (digito % 2)*10**peso
        
        
        if (resto1 + resto2 + llevada)>1:
            llevada=1;
            suma=suma + 1*10**(peso+1);
        else:
            llevada=0;
                      
        peso=peso+1;
        binario1=binario1//10;
        binario2=binario2//10;

    return(suma);

binario1=0;
binario2=0;
resultado=suma_binaria(binario1,binario2);
print("0 + 0 en binario es 0 y segun tu programa es %d." %resultado);
    
binario1=0;
binario2=1;
resultado=suma_binaria(binario1,binario2);
print("0 + 1 en binario es 1 y segun tu programa es %d." %resultado);

binario1=1;
binario2=0;
resultado=suma_binaria(binario1,binario2);
print("1 + 0 en binario es 1 y segun tu programa es %d." %resultado);

binario1=1;
binario2=1;
resultado=suma_binaria(binario1,binario2);
print("1 + 1 en binario es 10 y segun tu programa es %d." %resultado);

binario1=11;
binario2=11;
resultado=suma_binaria(binario1,binario2);
print("11 + 11 en binario es 110 y segun tu programa es %d." %resultado);

