def suma_inferiores(n):
    sumainf = 0;
    while n > 0:
        n = n-1;
        sumainf = sumainf + n;
    return (sumainf);

def suma_consecutivos(n):
    sumaco = 0;
    sumainf=suma_inferiores(n);
    while sumaco < sumainf:
        n = n+1;
        sumaco = sumaco + n;
    return (sumaco);

def es_medio(n):
    es_medio=False;
    sumaco=suma_consecutivos(n);
    sumainf=suma_inferiores(n);
    if sumaco==sumainf:
        es_medio=True;
        return es_medio;
    else:
        es_medio=False;
        return es_medio;
    

def prueba():
    #prueba 1
    n=6;
    respuesta=es_medio(n);
    print("La respuesta debería ser True y según tu programa es");
    print(respuesta);
    
    #prueba 2
    n=7;
    respuesta=es_medio(n);
    print("La respuesta debería ser False y según tu programa es");
    print(respuesta);
    
    #prueba 3
    n=35;
    respuesta=es_medio(n);
    print("La respuesta debería ser True y según tu programa es");
    print(respuesta);
    
prueba()