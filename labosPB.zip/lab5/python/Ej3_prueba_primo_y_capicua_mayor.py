from math import sqrt

def es_capicua(num):
    length = 0
    aux = num
    while aux != 0:
        aux = int(aux / 10)
        length += 1
    aux = num
    
    es_capicua = True
    i = int(length / 2) + 1
    cont = 0
    while cont < i and es_capicua:
        if (int(aux / 10**cont) % 10) != (int(num / 10**(length-cont-1)) % 10):
            es_capicua = False
        cont += 1
    
    return es_capicua
            
def es_primo(num):
    num_sqrt = round(sqrt(num))
    for i in range(num_sqrt, 1, -1):
        if num % i == 0:
            return False
    return True

def primo_y_capicua_mayor(num):
    num_posible = num
    numero_encontrado = False
    while not numero_encontrado:
        num_posible += 1
        numero_encontrado = es_capicua(num_posible) and es_primo(num_posible)
    return num_posible
        
def prueba():
    #prueba 1
    print('El valor de entrada es 1, tu programa debe devolver 2.')
    resultado=primo_y_capicua_mayor(1)
    print('Y devuelve %d.' %resultado)
    print('')
    #prueba 2
    print('El valor de entrada es 7, tu programa debe devolver 11.')
    resultado=primo_y_capicua_mayor(7)
    print('Y devuelve %d.' %resultado)   
    print('')
    #prueba 3
    print('El valor de entrada es 32, tu programa debe devolver 101.')
    resultado=primo_y_capicua_mayor(32)
    print('Y devuelve %d.' %resultado)   
    print('')
    #prueba 4
    print('El valor de entrada es 453, tu programa debe devolver 727.')
    resultado=primo_y_capicua_mayor(453)
    print('Y devuelve %d.' %resultado)
    print('')
     #prueba 5
    print('El valor de entrada es 3000000, tu programa debe devolver 3001003.')
    resultado=primo_y_capicua_mayor(3000000)
    print('Y devuelve %d.' %resultado)
    print('')
   
#Falta hacer la llamada al programa de pruebas

prueba()
