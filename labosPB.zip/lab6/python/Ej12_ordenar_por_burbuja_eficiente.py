def escribir_vector(V):
    for i in range(0, len(V)):
        print(V[i], end=" ")
    print()   


def ordenar_por_burbuja_eficiente(V):
    # Entrada: un vector de N > 0 elementos
    # Pre: los elementos no tienen por qué estar ordenados
    # Salida: un vector de N > 0 elementos
    # Post: el vector devuelto contiene los elementos de V en orden

    esta_ordenado = False
    num_recorridos = 1
    cambio = True

    while not (num_recorridos > len(V) - 1) and cambio:
        V_copia = V
        cambio = False
        for i in range(0, len(V) - 1):
            if V[i] > V[i + 1]:
                cambio = True
                aux = V[i]
                V[i] = V[i + 1]
                V[i + 1] = aux
        num_recorridos = num_recorridos + 1

    return(V)

def principal():
    #Caso 1 
    vector1 = [9, 5, 3, 4, 10, 8, 13, 24, 15, 11]
     
    print("El vector inicial es (9,5,3,4,10,8,13,24,15,11):")
    escribir_vector(vector1)

    vector1=ordenar_por_burbuja_eficiente(vector1)
    print("El vector final deberia ser (3,4,5,8,9,10,11,13,15,24) y es:")
    escribir_vector(vector1)
    print()

    # Caso 2
    vector1 = [0, 1, 2, 3, 4, 6, 5]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_burbuja_eficiente(vector1)
    print("El vector final debería ser (0, 1, 2, 3, 4, 5, 6) y es: ")
    escribir_vector(vector1)
    print()

    # Caso 3
    vector1 = [0]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_burbuja_eficiente(vector1)
    print("El vector final debería ser (0) y es: ")
    escribir_vector(vector1)
    print()

    # Caso 4
    vector1 = [1, 0]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_burbuja_eficiente(vector1)
    print("El vector final debería ser (0, 1) y es: ")
    escribir_vector(vector1)
    print()

    # Caso 4
    vector1 = [1, 0, 1]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_burbuja_eficiente(vector1)
    print("El vector final debería ser (0, 1, 1) y es: ")
    escribir_vector(vector1)
    print()
    
    # Caso 5
    vector1 = [1, 2, 1, 4]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_burbuja_eficiente(vector1)
    print("El vector final debería ser (1, 1, 2, 4) y es: ")
    escribir_vector(vector1)
    print()
    
    # Caso 6
    vector1 = [1, 2, 4, 4]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_burbuja_eficiente(vector1)
    print("El vector final debería ser (1, 2, 4, 4) y es: ")
    escribir_vector(vector1)
    print()
    
principal()
