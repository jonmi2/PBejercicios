def esta_en_vector_ordenado(x,vec):
    # Pre: 	el vector está ordenado y es un vector
    # 		de enteros. x es un número entero
    # Post: se devuelve True si x está en el vector,
    #		False si no está.
    # El subprograma dejará de comprobar si x está en vec
    # una vez encuentre un valor en vec mayor que x
    
    encontrado = False
    imposible = False
    
    '''
    for i in vec:
        if i == x:
            return True
        if i > x:
            return False
    return False
    '''
    
    i = 0
    while i < len(vec) and not encontrado and not imposible:
        if vec[i] == x:
            encontrado = True
        if vec[i] > x:
            imposible = True
        i = i + 1
    return encontrado
    

def principal():
   Vector1= [30, 31, 255, 270, 281, 290, 630, 700, 900, 960] 
   print("Prueba 1: el valor esta en medio")
   print(" esta_en_vector_ordenado(290, (30, 31, 255, 270, 281, 290, 630, 700, 900, 960))")
   print(" debe ser True y el resultado es ")
   rdo=esta_en_vector_ordenado(290,Vector1)
   print(rdo)
   print()

   Vector1=  [30, 31, 255, 270, 281, 290, 630, 700, 900, 960]
   print("Prueba 2: el valor esta al final")
   print(" esta_en_vector_ordenado(960, (30, 31, 255, 270, 281, 290, 630, 700, 900, 960))")
   print(" debe ser True y el resultado es ")
   rdo=esta_en_vector_ordenado(960,Vector1)
   print(rdo)
   print()

   Vector1=  [30, 31, 255, 270, 281, 290, 630, 700, 900, 960]
   print("Prueba 3: el valor no esta")
   print(" esta_en_vector_ordenado(45, (30, 31, 255, 270, 281, 290, 630, 700, 900, 960))")
   print(" debe ser False y el resultado es ")
   rdo=esta_en_vector_ordenado(45,Vector1)
   print(rdo)
   print()
    
    ###
   vec2 = [20, 50, 54]
   print("Prueba 4: el valor está al principio")
   print(" esta_en_vector_ordenado(20, [20, 50, 54])")
   print(" debe ser True y el resultado es", esta_en_vector_ordenado(20, vec2))
   print()
   print("Prueba 5: el valor está en el medio")
   print(" esta_en_vector_ordenado(50, [20, 50, 54])")
   print(" debe ser True y el resultado es", esta_en_vector_ordenado(50, vec2))
   print()
   print("Prueba 6: el valor está al final")
   print(" esta_en_vector_ordenado(54, [20, 50, 54])")
   print(" debe ser True y el resultado es", esta_en_vector_ordenado(54, vec2))
   print()

   ###
   vec3 = [20, 50]
   print("Prueba 7: el valor está al principio")
   print(" esta_en_vector_ordenado(20, [20, 50])")
   print(" debe ser True y el resultado es", esta_en_vector_ordenado(20, vec3))
   print()
   print("Prueba 8: el valor está al final")
   print(" esta_en_vector_ordenado(50, [20, 50])")
   print(" debe ser True y el resultado es", esta_en_vector_ordenado(50, vec3))
   print()

   ###
   vec4 = [20]
   print("Prueba 9: el valor está")
   print(" esta_en_vector_ordenado(20, [20])")
   print(" debe ser True y el resultado es", esta_en_vector_ordenado(20, vec4))
   print()

   ###
   vec4 = []
   print("Prueba 10: el valor no está")
   print(" esta_en_vector_ordenado(20, [])")
   print(" debe ser False y el resultado es", esta_en_vector_ordenado(20, vec4))
   print()




principal()
