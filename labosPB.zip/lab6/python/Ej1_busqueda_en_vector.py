def esta_en_vector(x,vec):
    #Pre: el vector no está ordenado y x es un numero entero.
    #Post: se devuelve True si x está en el vector y False si no está.
    #El subprograma dejará de comprobar cuando encuentre que x está en el vector.
    
    esta_en_vector = False;
    pos = 0;
    while pos<len(vec) and esta_en_vector==False:
        if x == vec[pos]:
            esta_en_vector = True;
        else:
            esta_en_vector = False;
            pos = pos+1;
        
        
    return(esta_en_vector)
    
def principal():
   #prueba1
   Vector1 = [1, 13, 55, 27, 99, 111, 133, 150, 17, 6]
   print("Prueba1: el valor esta en medio")
   print(" esta_en_vector(111, (1, 13, 55, 27, 99, 111, 133, 150, 17, 6))")
   print(" debe ser True y el resultado es ")
   rdo=esta_en_vector(111,Vector1)
   print(rdo)
   print()

   #prueba2
   Vector1 = [16, 33, 567, 73, 9, 111, 153, 15, 197, 1]
   print("Prueba2: el valor esta al final")
   print(" esta_en_vector(1, (16, 33, 567, 73, 9, 111, 153, 15, 197, 1))")
   print(" debe ser True y el resultado es ")
   rdo=esta_en_vector(1,Vector1)
   print(rdo)
   print()

   #prueba3
   Vector1 = [19, 3, 556, 72, 91, 11, 1, 15, 817, 199]
   print("Prueba3: el valor no esta")
   print(" esta_en_vector(45, (19, 3, 556, 72, 91, 11, 1, 15, 817, 199))")
   print(" debe ser False y el resultado es ")
   rdo=esta_en_vector(45,Vector1)
   print(rdo)
   print()

   #prueba4
   Vector1 = [21, 6, 564, 45, 75, 23, 2, 12, 67, 469]
   print("Prueba4: el valor esta al principio")
   print(" esta_en_vector(21, (21, 6, 564, 45, 75, 23, 2, 12, 67, 469))")
   print(" debe ser True y el resultado es ")
   rdo=esta_en_vector(21,Vector1)
   print(rdo)
   print()
   
   #prueba5
   Vector1 = [34, 4, 513, 33, 74, 88, 6, 57, 232, 34, 78, 989, 3]
   print("Prueba5: el valor esta al principio")
   print(" esta_en_vector(34, (34, 4, 513, 33, 74, 88, 6, 57, 232, 34, 78, 989, 3))")
   print(" debe ser True y el resultado es ")
   rdo=esta_en_vector(34,Vector1)
   print(rdo)
   print()
   
   #prueba6
   Vector1 = [34, 4, 513, 33, 74, 88, 6, 57, 232, 34, 78, 989, 3]
   print("Prueba6: el valor esta en el medio")
   print(" esta_en_vector(6, (34, 4, 513, 33, 74, 88, 6, 57, 232, 34, 78, 989, 3))")
   print(" debe ser True y el resultado es ")
   rdo=esta_en_vector(6,Vector1)
   print(rdo)
   print()   

   #prueba7
   Vector1 = [34, 4, 513, 33, 74, 88, 6, 57, 232, 34, 78, 989, 3]
   print("Prueba7: el valor esta en el final")
   print(" esta_en_vector(3, (34, 4, 513, 33, 74, 88, 6, 57, 232, 34, 78, 989, 3))")
   print(" debe ser True y el resultado es ")
   rdo=esta_en_vector(3,Vector1)
   print(rdo)
   print()  

   #prueba8
   Vector1 = [34, 4, 513, 33, 74, 88, 6, 57, 232, 34, 78, 989, 3]
   print("Prueba8: el valor no esta")
   print(" esta_en_vector(69, (34, 4, 513, 33, 74, 88, 6, 57, 232, 34, 78, 989, 3))")
   print(" debe ser false y el resultado es ")
   rdo=esta_en_vector(69,Vector1)
   print(rdo)
   print()  
    
   #prueba9
   Vector1 = [2,45]
   print("Prueba9: el valor esta en el final")
   print(" esta_en_vector(45, (2, 45))")
   print(" debe ser True y el resultado es ")
   rdo=esta_en_vector(45,Vector1)
   print(rdo)
   print()   
    
   #prueba10
   Vector1 = [2,45]
   print("Prueba10: el valor esta en el principio")
   print(" esta_en_vector(2, (2, 45))")
   print(" debe ser True y el resultado es ")
   rdo=esta_en_vector(2,Vector1)
   print(rdo)
   print() 
    
   #prueba11
   Vector1 = [2,45]
   print("Prueba11: el valor no esta")
   print(" esta_en_vector(56, (2, 45))")
   print(" debe ser False y el resultado es ")
   rdo=esta_en_vector(56,Vector1)
   print(rdo)
   print()
    
   #prueba12
   Vector1 = [5]
   print("Prueba12: el valor esta")
   print(" esta_en_vector(5, (5))")
   print(" debe ser True y el resultado es ")
   rdo=esta_en_vector(5,Vector1)
   print(rdo)
   print() 
    
   #prueba13
   Vector1 = [5]
   print("Prueba13: el valor no esta")
   print(" esta_en_vector(53, (5))")
   print(" debe ser False y el resultado es ")
   rdo=esta_en_vector(53,Vector1)
   print(rdo)
   print() 
    
   #prueba14
   Vector1 = []
   print("Prueba14: no hay ningun valor en el vector")
   print(" esta_en_vector(85, ())")
   print(" debe ser False y el resultado es ")
   rdo=esta_en_vector(85,Vector1)
   print(rdo)
   print() 
   
principal()