def escribir_vector(V):
    for i in range(0, len(V)):
        print(V[i], end=" ")
    print()

def intercambiar(V, posA, posB):
    aux = V[posA]
    V[posA] = V[posB]
    V[posB] = aux
	
    return(V)

def buscar_posicion_del_minimo(V, posComienzo):
    # Pre:	0 <= posComienzo < len(V)
    # Post: pos_min contiene la posicion del valor minimo de los
    #       comprendidos entre posComienzo y len(V)
    
    pos_min = posComienzo
    min = V[posComienzo]
    for i in range(posComienzo + 1, len(V)):
        if V[i] < min:
            min = V[i]
            pos_min = i
    

    return pos_min

def ordenar_por_seleccion(V):
    for i in range(0, len(V)):
        pos_min = buscar_posicion_del_minimo(V, i)
        V = intercambiar(V, i, pos_min)

    return(V)

def principal():
    #Caso 1 
    vector1 = [9, 5, 3, 4, 10, 8, 13, 24, 15, 11]
     
    print("El vector inicial es (9,5,3,4,10,8,13,24,15,11):")
    escribir_vector(vector1)

    vector1=ordenar_por_seleccion(vector1)
    print("El vector final deberia ser (3,4,5,8,9,10,11,13,15,24) y es:")
    escribir_vector(vector1)
    print()

    # Caso 2
    vector1 = [0, 3, 2]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_seleccion(vector1)
    print("El vector debería ser (0, 2, 3) y es: ")
    escribir_vector(vector1)
    print()
    
    # Caso 3
    vector1 = [0, 3]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_seleccion(vector1)
    print("El vector debería ser (0, 3) y es: ")
    escribir_vector(vector1)
    print()

    # Caso 4
    vector1 = [0]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_seleccion(vector1)
    print("El vector debería ser (0) y es: ")
    escribir_vector(vector1)
    print()
    
    # Caso 5
    vector1 = [0, 3, 2, 3]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_seleccion(vector1)
    print("El vector debería ser (0, 2, 3, 3) y es: ")
    escribir_vector(vector1)
    print()

    # Caso 6
    vector1 = [3, 3, 3]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_seleccion(vector1)
    print("El vector debería ser (3, 3, 3) y es: ")
    escribir_vector(vector1)
    print()

    # Caso 7
    vector1 = [1, 2, 3]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_seleccion(vector1)
    print("El vector debería ser (1, 2, 3) y es: ")
    escribir_vector(vector1)
    print()

    # Caso 8
    vector1 = [4, 3, 2, 1]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_seleccion(vector1)
    print("El vector debería ser (1, 2, 3, 4) y es: ")
    escribir_vector(vector1)
    print()

    # Caso 9
    vector1 = [1, 2, 4]
    print("El vector inicial es: ")
    escribir_vector(vector1)
    vector1 = ordenar_por_seleccion(vector1)
    print("El vector debería ser (1, 2, 4) y es: ")
    escribir_vector(vector1)
    print()

principal()
