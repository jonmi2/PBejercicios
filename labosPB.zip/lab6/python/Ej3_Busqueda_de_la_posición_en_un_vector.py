def esta_en_posicion(x,vec):
    #Pre:El vector estará compuesto de N enteros.
    #Post:Si el entero está repetido vale con devolver una cualquiera de sus posiciones, y si el entero no está en el vector se devolverá el valor -1.

    esta_en_posicion = False;
    posi = 0;
    while posi<len(vec) and esta_en_posicion==False:
        if x == vec[posi]:
            esta_en_posicion = True;
        else:
            esta_en_posicion = False;
            posi = posi + 1;
        
    if posi>=len(vec) and esta_en_posicion == False:  
        posi = -1;
        
    return(esta_en_posicion, posi)
    
def principal():
   Vector1 = [1, 3, 5, 17, 9, 11, 131, 15, 170, 19]
   print("Prueba 1:  el valor esta en medio")
   print(" esta_en_posicion(131, (1, 3, 5, 17, 9, 11, 131, 15, 170, 19))")
   print(" debe ser True y el resultado es ")
   rdo, posi=esta_en_posicion(131,Vector1)
   if rdo:
        print("el numero %d esta en la posicion %d " %(131,posi))
   else:
        print("El numero no esta")
   print ()

   Vector1 = [1, 3, 5, 17, 9, 11, 131, 15, 170, 19]
   print("Prueba 2:  el valor esta al final")
   print(" esta_en_posicion(19, (1, 3, 5, 17, 9, 11, 131, 15, 170, 19))")
   print(" debe ser True y el resultado es ")
   rdo, posi=esta_en_posicion(19,Vector1)
   if rdo:
        print("el numero %d esta en la posicion %d " %(19,posi))
   else:
        print("El numero no esta")
   print ()

   Vector1 = [1, 3, 5, 17, 9, 11, 131, 15, 170, 19]
   print("Prueba 3: el numero no esta ")
   print(" esta_en_posicion(1912, (1, 3, 5, 17, 9, 11, 131, 15, 170, 19))")
   print(" debe ser False y el resultado es ")
   rdo, posi=esta_en_posicion(1912,Vector1)
   if rdo:
        print("el numero %d esta en la posicion %d " %(1912,posi))
   else:
        print("El numero no esta")
   print ()

   Vector1 = [1, 3, 5, 17, 9, 11, 131, 15, 170, 19]
   print("Prueba 4: el numero esta al principio ")
   print(" esta_en_posicion(1, (1, 3, 5, 17, 9, 11, 131, 15, 170, 19))")
   print(" debe ser True y el resultado es ")
   rdo, posi=esta_en_posicion(1,Vector1)
   if rdo:
        print("el numero %d esta en la posicion %d " %(1,posi))
   else:
        print("El numero no esta")
   print ()

   Vector1 = [1, 31, 5, 17, 9, 11, 31, 15, 170, 19]
   print("Prueba 5: el numero esta repetido ")
   print(" esta_en_posicion(31, (1, 31, 5, 17, 9, 11, 31, 15, 170, 19))")
   print(" debe ser True y el resultado es ")
   rdo, posi=esta_en_posicion(31,Vector1)
   if rdo:
        print("el numero %d esta en la posicion %d " %(31,posi))
   else:
        print("El numero no esta")
   print ()

principal()
