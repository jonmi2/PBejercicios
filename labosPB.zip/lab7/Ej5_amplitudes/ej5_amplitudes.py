def escribir_lista(L):
    print("[ ", end="")
    for i in range(0,len(L)):
        print(str(L[i]) + " ", end="")        
    print("]", end="")
    
def calcular_amplitud_max (Lista): 
    # Pre: Lista tiene al menos dos elementos y comienza con una
    #      subsecuencia ascendente 
    #      La lista no tiene dos elementos iguales consecutivos
    # Post: Devuelve la longitud del segmento de mayor amplitud
    #       En caso de que no haya ningun segmento el resultado sera cero
    amplitud=0;
    ascendente=True;
    segmento=False;
    i=1;
    
    if len(Lista)<=2:
        segmento=False;
        
    if Lista[i-1]<Lista[i]:
        ascendente=True;
    else:
        ascendente=False;
        
    while 0<i<=len(Lista)-2:
        if ascendente==True and (Lista[i]>Lista[i+1]):
            segmento=True;
        else:
            segmento=False;
             
            if segmento==False:
                amplitud=0;
                
            while segmento==True:
                amplitud=amplitud+1;
          
        
     
            
    i=i+1;       
    return amplitud

def prueba_calcular_amplitud_max(): 
   # Este programa hace llamadas a la funcion calcular_amplitud_max y  
   # permite comprobar si su funcionamiento es correcto
    
    L = [12, 16]
   
    print("Prueba 1: Solo ascendente, dos elementos")
    print("La entrada es ", end="")
    escribir_lista(L)
    print(". El resultado deberia ser 0 y es: ")
    print(calcular_amplitud_max(L))
    print()
    
    L = [1, 3, 4, 6, 5, 4]
   
    print("Prueba 2: Es segmento, 6 elementos")
    print("La entrada es ", end="")
    escribir_lista(L)
    print(". El resultado deberia ser 6 y es: ")
    print(calcular_amplitud_max(L))
    print()
    
    L = [1, 3, 4, 6, 5, 4, 6, 7, 9]
   
    print("Prueba 3: Es segmento, 6 elementos")
    print("La entrada es ", end="")
    escribir_lista(L)
    print(". El resultado deberia ser 6 y es: ")
    print(calcular_amplitud_max(L))
    print()
    
    L = [1, 3, 4, 6, 5, 4, 6, 7, 9, 8, 7, 6, 5, 4, 3]
   
    print("Prueba 4: Es segmento, 10 elementos")
    print("La entrada es ", end="")
    escribir_lista(L)
    print(". El resultado deberia ser 10 y es: ")
    print(calcular_amplitud_max(L))
    print()
    
    L = [1, 3, 4, 6, 5, 4, 6, 7, 9, 8, 7, 6, 5, 4, 3, 6, 7, 8]
   
    print("Prueba 5: Es segmento, 10 elementos")
    print("La entrada es ", end="")
    escribir_lista(L)
    print(". El resultado deberia ser 10 y es: ")
    print(calcular_amplitud_max(L))
    print()
   
prueba_calcular_amplitud_max()